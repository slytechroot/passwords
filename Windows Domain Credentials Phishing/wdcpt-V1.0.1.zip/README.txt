OUTLOOK.exe "Domain Name" "Password File Name"
e.g: OUTLOOK.exe acme.local creds.txt

The credentials file will be save to the user temp folder.


Change Log
==========

13/04/2014 - Version 1.0.1 - All attempts will be logged to text file.
 
This tool shall not be used in illegal activities.